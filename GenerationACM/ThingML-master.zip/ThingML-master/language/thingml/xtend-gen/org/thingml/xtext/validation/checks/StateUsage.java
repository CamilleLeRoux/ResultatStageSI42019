package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class StateUsage extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object chectStateUniqueness(final /* org.thingml.xtext.thingML.State */Object s) {
    throw new Error("Unresolved compilation problems:"
      + "\nStateContainer cannot be resolved to a type."
      + "\nStateContainer cannot be resolved to a type."
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, StateContainer, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\neContainer cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstateContainer_Substate cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkSessionUniqueness(final /* Session */Object s) {
    throw new Error("Unresolved compilation problems:"
      + "\nCompositeState cannot be resolved to a type."
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, CompositeState, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\neContainer cannot be resolved"
      + "\nsession cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncompositeState_Session cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object chectRegionUniqueness(final /* Region */Object r) {
    throw new Error("Unresolved compilation problems:"
      + "\nCompositeState cannot be resolved to a type."
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, CompositeState, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\neContainer cannot be resolved"
      + "\nregion cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncompositeState_Region cannot be resolved"
      + "\nregion cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkUnreachableState(final /* StateContainer */Object sc) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field outgoing is undefined for the type Object"
      + "\nThe method or field target is undefined for the type Object"
      + "\nThe method warning(String, StateContainer, Object, Object, String, Object) is undefined"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nsubstate cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\ninitial cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nexists cannot be resolved"
      + "\nexists cannot be resolved"
      + "\n== cannot be resolved"
      + "\n! cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstateContainer_Substate cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public void checkSinkState(final /* CompositeState */Object c) {
    throw new Error("Unresolved compilation problems:"
      + "\nCompositeState cannot be resolved to a type."
      + "\nFinalState cannot be resolved to a type."
      + "\nThe method isDefined(CompositeState, String, String) is undefined for the type Class<AnnotatedElementHelper>"
      + "\nThe method or field internal is undefined for the type Object"
      + "\nThe method or field outgoing is undefined for the type Object"
      + "\nThe method isDefined(Object, String, String) is undefined for the type Class<AnnotatedElementHelper>"
      + "\nThe method warning(String, Object, Object, String, Object) is undefined"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\ninternal cannot be resolved"
      + "\nempty cannot be resolved"
      + "\n! cannot be resolved"
      + "\noutgoing cannot be resolved"
      + "\nempty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\nempty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nempty cannot be resolved"
      + "\n! cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nnamedElement_Name cannot be resolved");
  }
}
