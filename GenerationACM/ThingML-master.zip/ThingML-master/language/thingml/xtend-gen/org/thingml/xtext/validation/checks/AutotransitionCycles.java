package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class AutotransitionCycles extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object checkAutotransitionCycles(final /* StateContainer */Object c) {
    throw new Error("Unresolved compilation problems:"
      + "\nTarjan cannot be resolved."
      + "\nThe method or field name is undefined"
      + "\nThe method error(String, StateContainer, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nAmbiguous feature call.\nThe extension methods\n\t<T> join(Iterable<T>, CharSequence, CharSequence, CharSequence, Function1<? super T, ? extends CharSequence>) in IterableExtensions and\n\t<T> join(Iterator<T>, CharSequence, CharSequence, CharSequence, Function1<? super T, ? extends CharSequence>) in IteratorExtensions\nboth match."
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nsubstate cannot be resolved"
      + "\nfindStronglyConnectedComponents cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstateContainer_Substate cannot be resolved"
      + "\nsubstate cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
}
