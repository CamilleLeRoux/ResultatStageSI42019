package org.thingml.xtext.validation.checks;

import org.eclipse.xtend.lib.Property;
import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class ThingsUsage extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object checkInstance(final /* Instance */Object i) {
    throw new Error("Unresolved compilation problems:"
      + "\nConfiguration cannot be resolved to a type."
      + "\nThe method error(String, Object, Object, Object, String, Object) is undefined"
      + "\ntype cannot be resolved"
      + "\nfragment cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\ngetType cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\ngetType cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\neContainingFeature cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\ninstances cannot be resolved"
      + "\nindexOf cannot be resolved"
      + "\nname cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkInstanceUniqueness(final /* Instance */Object i) {
    throw new Error("Unresolved compilation problems:"
      + "\nConfiguration cannot be resolved to a type."
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, Configuration, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\neContainer cannot be resolved"
      + "\ninstances cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nconfiguration_Instances cannot be resolved"
      + "\ninstances cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkPropertyUniqueness(final Property p) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method findContainingThing(Property) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method allProperties(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method or field name is undefined for the type Property"
      + "\nThe method getName() is undefined for the type Property"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthing_Properties cannot be resolved"
      + "\nproperties cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkMessageUniqueness(final /* Message */Object m) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method findContainingThing(Message) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method allMessages(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthing_Messages cannot be resolved"
      + "\nmessages cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkPortUniqueness(final /* Port */Object p) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method findContainingThing(Port) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method allPorts(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthing_Ports cannot be resolved"
      + "\nports cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkFunctionUniqueness(final /* Function */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method findContainingThing(Function) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method allFunctions(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field abstract is undefined for the type Object"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nabstract cannot be resolved"
      + "\n&& cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\ngetName cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthing_Functions cannot be resolved"
      + "\nfunctions cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
}
