package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class Datatypes extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object checkDatatypeUniqueness(final /* PrimitiveType */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\nPrimitiveType cannot be resolved to a type."
      + "\nThe method findContainingModel(PrimitiveType) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method allSimpleTypes(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field name is undefined for the type Object"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\nname cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthingMLModel_Types cannot be resolved"
      + "\ntypes cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
}
