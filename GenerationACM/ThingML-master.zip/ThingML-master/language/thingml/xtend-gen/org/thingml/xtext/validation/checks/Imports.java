package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class Imports extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object checkImports(final /* ThingMLModel */Object model) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method getModelFromRelativeURI(Object, Object, Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method findContainingModel(Object) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method or field importURI is undefined for the type Object"
      + "\nThe method or field from is undefined for the type Object"
      + "\nThe method error(String, ThingMLModel, Object, Object) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nimports cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nthingMLModel_Imports cannot be resolved");
  }
}
