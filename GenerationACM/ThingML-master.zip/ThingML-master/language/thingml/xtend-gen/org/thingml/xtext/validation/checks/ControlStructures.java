package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class ControlStructures extends ThingMLValidatorCheck {
  public void checkActionExpression(final /* Action */Object a, final /* Expression */Object e) {
    throw new Error("Unresolved compilation problems:"
      + "\nExternExpression cannot be resolved to a type."
      + "\nThe method computeTypeOf(Expression) is undefined for the type Class<TypeChecker>"
      + "\nThe method or field BOOLEAN_TYPE is undefined for the type Class<Types>"
      + "\nThe method findContainingThing(Action) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method isDefined(Object, String, String) is undefined for the type Class<AnnotatedElementHelper>"
      + "\nThe method or field ANY_TYPE is undefined for the type Class<Types>"
      + "\nThe method warning(String, Action, Object, String) is undefined"
      + "\nThe method warning(String, Action, Object, String, String) is undefined"
      + "\nThe method error(String, Action, Object, String) is undefined"
      + "\nThe method getBroadType(Object) is undefined for the type Class<TyperHelper>"
      + "\nequals cannot be resolved"
      + "\n! cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nequals cannot be resolved"
      + "\neContainingFeature cannot be resolved"
      + "\neContainingFeature cannot be resolved"
      + "\nname cannot be resolved"
      + "\neContainingFeature cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public void checkConditionalAction(final /* ConditionalAction */Object ca) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method checkActionExpression(Action, Expression) from the type ControlStructures refers to the missing type Action"
      + "\ncondition cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public void checkLoopAction(final /* LoopAction */Object la) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method checkActionExpression(Action, Expression) from the type ControlStructures refers to the missing type Action"
      + "\ncondition cannot be resolved");
  }
}
