package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class Annotations extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public void checkAnnotation(final /* PlatformAnnotation */Object a) {
    throw new Error("Unresolved compilation problems:"
      + "\nAnnotatedElement cannot be resolved to a type."
      + "\nThe method warning(String, AnnotatedElement, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThe method warning(String, AnnotatedElement, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\neContainer cannot be resolved"
      + "\nname cannot be resolved"
      + "\nname cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nannotatedElement_Annotations cannot be resolved"
      + "\nannotations cannot be resolved"
      + "\nindexOf cannot be resolved"
      + "\nname cannot be resolved"
      + "\nvalue cannot be resolved"
      + "\nname cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nannotatedElement_Annotations cannot be resolved"
      + "\nannotations cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
}
