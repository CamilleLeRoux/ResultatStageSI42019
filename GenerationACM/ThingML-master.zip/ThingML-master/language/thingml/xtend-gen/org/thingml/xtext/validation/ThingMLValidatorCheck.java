package org.thingml.xtext.validation;

import org.eclipse.xtext.validation.EValidatorRegistrar;

@SuppressWarnings("all")
public class ThingMLValidatorCheck /* implements AbstractThingMLValidator  */{
  /*@Override*/
  public Object register(final EValidatorRegistrar registrar) {
    return null;
  }
}
