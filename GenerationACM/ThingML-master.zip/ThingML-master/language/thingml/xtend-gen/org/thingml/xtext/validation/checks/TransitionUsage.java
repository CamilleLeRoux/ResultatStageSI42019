package org.thingml.xtext.validation.checks;

import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.thingml.xtext.validation.ThingMLValidatorCheck;

@SuppressWarnings("all")
public class TransitionUsage extends ThingMLValidatorCheck {
  @Check(CheckType.FAST)
  public Object checkNonDeterministicTransition(final /* org.thingml.xtext.thingML.State */Object s) {
    throw new Error("Unresolved compilation problems:"
      + "\nReceiveMessage cannot be resolved to a type."
      + "\nReceiveMessage cannot be resolved to a type."
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method or field guard is undefined for the type Object"
      + "\nThe method or field guard is undefined for the type Object"
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method error(String, State, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\noutgoing cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\noutgoing cannot be resolved"
      + "\nforEach cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n|| cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nport cannot be resolved"
      + "\nname cannot be resolved"
      + "\n+ cannot be resolved"
      + "\n+ cannot be resolved"
      + "\nmessage cannot be resolved"
      + "\nname cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstate_Outgoing cannot be resolved"
      + "\noutgoing cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkGreedyTransition(final /* org.thingml.xtext.thingML.State */Object s) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field event is undefined for the type Object"
      + "\nThe method or field guard is undefined for the type Object"
      + "\nThe method warning(String, State, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\noutgoing cannot be resolved"
      + "\nfindFirst cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n&& cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n!== cannot be resolved"
      + "\n&& cannot be resolved"
      + "\noutgoing cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\ntarget cannot be resolved"
      + "\nname cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstate_Outgoing cannot be resolved"
      + "\noutgoing cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkEmptyAutotransition(final /* Transition */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\norg.thingml.xtext.thingML.State cannot be resolved to a type."
      + "\nThe method findContainingState(Transition) is undefined for the type Class<ThingMLHelpers>"
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nevent cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nguard cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ntarget cannot be resolved"
      + "\n== cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstate_Outgoing cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\ninternal cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkEmptyInternal(final /* InternalTransition */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\norg.thingml.xtext.thingML.State cannot be resolved to a type."
      + "\nThe method error(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\nevent cannot be resolved"
      + "\n=== cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nguard cannot be resolved"
      + "\n=== cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstate_Internal cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\ninternal cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  @Check(CheckType.FAST)
  public Object checkInternalWithoutAction(final /* InternalTransition */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\norg.thingml.xtext.thingML.State cannot be resolved to a type."
      + "\nThe method warning(String, Object, Object, Object, String) is undefined"
      + "\nThe method or field ThingMLPackage is undefined"
      + "\naction cannot be resolved"
      + "\n=== cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\nstate_Internal cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\ninternal cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
}
