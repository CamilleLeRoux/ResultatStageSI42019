# ThingML-PlantUML
ThingML to PlantUML compiler to generate UML diagrams from ThingML models
