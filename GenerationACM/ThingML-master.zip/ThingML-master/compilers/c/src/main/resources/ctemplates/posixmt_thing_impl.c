/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing /*NAME*/
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "/*NAME*/.h"

/*CODE*/
