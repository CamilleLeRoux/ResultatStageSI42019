    int /*MESSAGE_NAME*/_length();
    int /*MESSAGE_NAME*/_available();
    inline boolean /*MESSAGE_NAME*/_isEmpty();

    void /*MESSAGE_NAME*/_queueEvent/*MESSAGE_PARAMETERS*/;
    void /*MESSAGE_NAME*/_popEvent(/*POP_PARAMETERS*/);
    void /*MESSAGE_NAME*/_removeEvent();
    void check/*MESSAGE_NAME*/TTL();
