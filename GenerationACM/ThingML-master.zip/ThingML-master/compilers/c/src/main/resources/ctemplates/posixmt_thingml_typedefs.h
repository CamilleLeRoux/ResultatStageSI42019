/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *       Definitions of datatypes and enums
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef THINGML_TYPEDEFS_H_
#define THINGML_TYPEDEFS_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdint.h>
#include <stdbool.h>

/*TYPEDEFS*/

/*typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef signed short   int16;
typedef unsigned long  uint32;
typedef signed char    int8;*/


#ifdef __cplusplus
}
#endif

#endif //THINGML_TYPEDEFS_H_
