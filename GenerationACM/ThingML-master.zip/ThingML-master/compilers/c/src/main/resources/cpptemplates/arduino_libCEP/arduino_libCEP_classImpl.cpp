stream_/*STREAM_NAME*/::stream_/*STREAM_NAME*/()
{}

stream_/*STREAM_NAME*/::~stream_/*STREAM_NAME*/()
{}

void stream_/*STREAM_NAME*/::checkTrigger(/*TRIGGER_INST_PARAM*/)
{
/*TRIGGER_IMPL*/
}

/*MESSAGE_IMPL*/

/*TRIGGER_TIMER_IMPL*/