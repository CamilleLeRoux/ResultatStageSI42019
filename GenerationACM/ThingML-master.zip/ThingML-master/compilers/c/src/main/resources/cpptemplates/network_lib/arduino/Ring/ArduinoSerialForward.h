//#ifndef ArduinoSerialForward_h
//
//#define ArduinoSerialForward_h
//#include <Arduino.h>
//#include "ArduinoSerialForward.c"
//
//void /*PORT_NAME*/_setup(long bps);
//void /*PORT_NAME*/_setListenerID(uint16_t id);
//void /*PORT_NAME*/_forwardMessage(byte * msg, uint8_t size);
//void /*PORT_NAME*/_read();

//#endif
