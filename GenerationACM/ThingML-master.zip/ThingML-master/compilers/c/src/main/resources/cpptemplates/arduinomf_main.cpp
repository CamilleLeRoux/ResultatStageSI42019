/*C_HEADERS*/

/*CONFIGURATION*/

/*C_GLOBALS*/

void setup() {
/*INIT_CODE*/
}

void loop() {
/*POLL_CODE*/
    processMessageQueue();
}
