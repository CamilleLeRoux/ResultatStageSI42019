/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing /*NAME*/
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef /*NAME*/_H_
#define /*NAME*/_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"
#include "runtime.h"

/*HEADER*/

#ifdef __cplusplus
}
#endif

#endif ///*NAME*/_H_
