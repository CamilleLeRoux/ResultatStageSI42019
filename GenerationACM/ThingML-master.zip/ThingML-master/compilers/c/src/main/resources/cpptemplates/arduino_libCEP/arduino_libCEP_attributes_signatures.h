    byte /*MESSAGE_NAME*/_fifo[/*STREAM_NAME_UPPER*/_/*MESSAGE_NAME_UPPER*/_FIFO_SIZE];
    unsigned int /*MESSAGE_NAME*/_fifo_head = 0;
    unsigned int /*MESSAGE_NAME*/_fifo_tail = 0;
