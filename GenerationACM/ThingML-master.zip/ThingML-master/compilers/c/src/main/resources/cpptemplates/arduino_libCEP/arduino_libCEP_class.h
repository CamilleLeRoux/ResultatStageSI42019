#define TIMESTAMP_DATASIZE 4
#define DEFAULT_NUMBER_MSG 1

/*STREAM_CONSTANTS*/
class stream_/*STREAM_NAME*/
{
  public:
    stream_/*STREAM_NAME*/();
    ~stream_/*STREAM_NAME*/();

/*METHOD_SIGNATURES*/
    void checkTrigger(/*TRIGGER_INST_PARAM*/);
    /*TRIGGER_TIMER_SIGNATURES*/

  private:
/*ATTRIBUTES_SIGNATURES*/
};
