package org.thingml.ACM;

import java.io.File;
import java.io.IOException;
import java.util.*;

import com.sun.xml.internal.bind.v2.TODO;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jdt.internal.debug.eval.ast.instructions.SendMessage;
import org.eclipse.pde.internal.runtime.MessageHelper;
import org.eclipse.xtext.resource.SaveOptions;
import org.eclipse.xtext.resource.XtextResource;
import org.thingml.thingmltools.ThingMLTool;
import org.thingml.xtext.ThingMLStandaloneSetup;
import org.thingml.xtext.constraints.ThingMLHelpers;
import org.thingml.xtext.helpers.ActionHelper;
import org.thingml.xtext.helpers.AnnotatedElementHelper;
import org.thingml.xtext.thingML.*;
import org.thingml.xtext.helpers.StateHelper;

public class ACMGenerator extends ThingMLTool {
	public ACMGenerator() {
        super();
    }

    @Override
    public String getID() {
        return "acm";
    }

    @Override
    public String getName() {
        return "ThingML ACM generator to add an ACM";
    }

    @Override
    public String getDescription() {
        return "ThingML ACM generator to add an ACM";
    }

    @Override
    public ThingMLTool clone() {
        return new ACMGenerator();
    }

    @Override
    public void generateThingMLFrom(ThingMLModel model) {
        ThingMLModel newModel = model;
        System.out.println("[" + getID() + "] Processing Model " + newModel.eResource().getURI().toString() + "\n");

        setOutputDirectory(new File(model.eResource().getURI().path()).getParentFile());
        ArrayList<Thing> inputs = new ArrayList<>();
        Thing output = ThingMLFactory.eINSTANCE.createThing();

        /*for (Thing t : ThingMLHelpers.allThings(model))
        {
			if (AnnotatedElementHelper.isDefined(t, "acm", "and"))
			{
				System.out.println("[" + getID() + "] Generating for Thing: " + t.getName() + "\n");
				//generateACMAnd(t);

			}
        }*/

        for (Thing t : ThingMLHelpers.allThings(newModel))
        {
            if (AnnotatedElementHelper.isDefined(t, "acm", "output"))
            {
               output = t;
            }

            if (AnnotatedElementHelper.isDefined(t, "acm", "input"))
            {
                inputs.add(t);
            }
        }
        if(output != null && !inputs.isEmpty()) {
            newModel = generateACMAnd(newModel, output, inputs);
        }

        System.out.println("[" + getID() + "] Done. (Model " + newModel.eResource().getURI().toString() + ")\n");

        final File acmFile = new File(outDir, "acm/codeWithACM.thingml");
        try {
            save(ThingMLHelpers.flattenModel(newModel), acmFile.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("Error while saving the instrumented model...");
            e.printStackTrace();
            System.exit(1);
        }
    }

    public ThingMLModel generateACMAnd(ThingMLModel mod, Thing output, ArrayList<Thing> inputs){
	    ThingMLModel newMod = mod;
	    Thing acmThing = ThingMLFactory.eINSTANCE.createThing();
        acmThing.setName("ACM");
        acmThing.getIncludes().addAll(output.getIncludes());

        //Get the ports from inputs and make them from required to provided
        for (Thing t : inputs) {
            ArrayList<Port> portsToDelete = new ArrayList<>();
            ArrayList<Port> portsToAdd = new ArrayList<>();
            for (Port p : t.getPorts()) {
                if(p instanceof RequiredPort){
                    portsToDelete.add(p);
                    ProvidedPort newPort = ThingMLFactory.eINSTANCE.createProvidedPort();
                    newPort.setName(p.getName());
                    newPort.getSends().addAll(p.getSends());
                    portsToAdd.add(newPort);
                }
            }
            t.getPorts().removeAll(portsToDelete);
            t.getPorts().addAll(portsToAdd);
        }

        //Add the corresponding ports from inputs into the acm thing
        int counter = 1;
        for (Thing t : inputs){
            ArrayList<Port> portsToAdd = new ArrayList<>();
            for(Port p : t.getPorts()){
                if(p instanceof ProvidedPort ){
                    RequiredPort newPort = ThingMLFactory.eINSTANCE.createRequiredPort();
                    newPort.setName(p.getName());
                    newPort.getReceives().addAll(p.getSends());
                    newPort.setName("Led" + counter);
                    ++counter;
                    portsToAdd.add(newPort);
                }
            }
            acmThing.getPorts().addAll(portsToAdd);
        }

        //Add the corresponding port from ouput to acm thing
        ArrayList<Port> outputPortsToAdd = new ArrayList<>();
        for(Port p : output.getPorts()){
            if(p instanceof ProvidedPort ){
                RequiredPort newPort = ThingMLFactory.eINSTANCE.createRequiredPort();
                newPort.setName(p.getName());
                newPort.getSends().addAll(p.getReceives());
                newPort.setName("LedFinal");
                outputPortsToAdd.add(newPort);
            }
        }
        acmThing.getPorts().addAll(outputPortsToAdd);

        //Create all the states for the acm thing
        State acmInit = ThingMLFactory.eINSTANCE.createState();
        acmInit.setName("Init");
        State acmWait1 = ThingMLFactory.eINSTANCE.createState();
        acmWait1.setName("Wait1");
        State acmWait2 = ThingMLFactory.eINSTANCE.createState();
        acmWait2.setName("Wait2");
        State ledOn = ThingMLFactory.eINSTANCE.createState();
        ledOn.setName("LedOn");

        //Create all the transition for the states of the acm
        Transition t1 =ThingMLFactory.eINSTANCE.createTransition();
        t1.setName("Wait1");
        t1.setTarget(acmWait1);
        ReceiveMessage e1 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e1.setName("message1");
        e1.setPort(acmThing.getPorts().get(0));
        e1.setMessage(acmThing.getPorts().get(0).getReceives().get(0));
        t1.setEvent(e1);

        Transition t2 =ThingMLFactory.eINSTANCE.createTransition();
        t2.setTarget(acmWait2);
        t2.setName("Wait2");
        ReceiveMessage e2 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e2.setName("message2");
        e2.setPort(acmThing.getPorts().get(1));
        e2.setMessage(acmThing.getPorts().get(1).getReceives().get(0));
        t2.setEvent(e2);

        acmInit.getOutgoing().add(t1);
        acmInit.getOutgoing().add(t2);

        Transition t3 =ThingMLFactory.eINSTANCE.createTransition();
        t3.setName("start");
        t3.setTarget(ledOn);
        ReceiveMessage e3 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e3.setName("message3");
        e3.setPort(acmThing.getPorts().get(1));
        e3.setMessage(acmThing.getPorts().get(1).getReceives().get(0));
        t3.setEvent(e3);

        acmWait1.getOutgoing().add(t3);

        Transition t4 = ThingMLFactory.eINSTANCE.createTransition();
        t4.setName("start");
        t4.setTarget(ledOn);
        ReceiveMessage e4 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e4.setName("message4");
        e4.setPort(acmThing.getPorts().get(0));
        e4.setMessage(acmThing.getPorts().get(0).getReceives().get(0));
        t4.setEvent(e4);

        acmWait2.getOutgoing().add(t4);

        SendAction a = ThingMLFactory.eINSTANCE.createSendAction();
        a.setPort(acmThing.getPorts().get(2));
        a.setMessage(acmThing.getPorts().get(2).getSends().get(0));
        ledOn.setEntry(a);

        CompositeState behaviour = ThingMLFactory.eINSTANCE.createCompositeState();
        behaviour.setName("ACMImpl");

        acmThing.setBehaviour(behaviour);

        acmThing.getBehaviour().getSubstate().add(acmInit);
        acmThing.getBehaviour().getSubstate().add(acmWait1);
        acmThing.getBehaviour().getSubstate().add(acmWait2);
        acmThing.getBehaviour().getSubstate().add(ledOn);
        acmThing.getBehaviour().setInitial(acmInit);

        newMod.getTypes().add(acmThing);

        //Creation of the acm instance
        Instance acmInstance = ThingMLFactory.eINSTANCE.createInstance();
        acmInstance.setType(acmThing);
        acmInstance.setName("ACM");
        newMod.getConfigs().get(0).getInstances().add(acmInstance);

        //Add the new connectors to the model configuration
        ArrayList<AbstractConnector> connectorsToDelete = new ArrayList<>();

        for(AbstractConnector connector : newMod.getConfigs().get(0).getConnectors()){
            Connector tmp = (Connector)connector;
            if(tmp.getCli().getType().getName().equals(inputs.get(0).getName()) && tmp.getSrv().getType().getName().equals(output.getName())){
                connectorsToDelete.add(connector);
            }
            if(tmp.getCli().getType().getName().equals(inputs.get(1).getName()) && tmp.getSrv().getType().getName().equals(output.getName())){
                connectorsToDelete.add(connector);
            }
        }

        newMod.getConfigs().get(0).getConnectors().removeAll(connectorsToDelete);

        Instance outputI = ThingMLFactory.eINSTANCE.createInstance();
        Instance inputI = ThingMLFactory.eINSTANCE.createInstance();
        Instance inputI2 = ThingMLFactory.eINSTANCE.createInstance();

        for(Instance i : ThingMLHelpers.allInstances(newMod.getConfigs().get(0))){
            if(i.getType().getName().equals(output.getName())){
                outputI = i;
            }else if(i.getType().getName().equals(inputs.get(0).getName())){
                inputI = i;
            }else if(i.getType().getName().equals(inputs.get(1).getName())){
                inputI2 = i;
            }
        }

        Connector acmToO = ThingMLFactory.eINSTANCE.createConnector();
        acmToO.setSrv(outputI);
        acmToO.setCli(acmInstance);
        acmToO.setName(acmToO.getCli().getName() + "TO" + acmToO.getSrv().getName());
        acmToO.setProvided((ProvidedPort)output.getPorts().get(0));
        acmToO.setRequired((RequiredPort) acmThing.getPorts().get(2));

        Connector acmToI1 = ThingMLFactory.eINSTANCE.createConnector();
        acmToI1.setSrv(inputI);
        acmToI1.setCli(acmInstance);
        acmToI1.setName(acmToI1.getCli().getName() + "TO" + acmToI1.getSrv().getName());
        acmToI1.setProvided((ProvidedPort)inputs.get(0).getPorts().get(0));
        acmToI1.setRequired((RequiredPort) acmThing.getPorts().get(0));

        Connector acmToI2 = ThingMLFactory.eINSTANCE.createConnector();
        acmToI2.setSrv(inputI2);
        acmToI2.setCli(acmInstance);
        acmToI2.setName(acmToI2.getCli().getName() + "TO" + acmToI2.getSrv().getName());
        acmToI2.setProvided((ProvidedPort)inputs.get(1).getPorts().get(0));
        acmToI2.setRequired((RequiredPort) acmThing.getPorts().get(1));

        newMod.getConfigs().get(0).getConnectors().add(acmToO);
        newMod.getConfigs().get(0).getConnectors().add(acmToI1);
        newMod.getConfigs().get(0).getConnectors().add(acmToI2);

        return newMod;
    }

    //TODO : Make an ACM directly in the output thing
    /*public void generateACMAnd(Thing t) {

	    int i = 0;
	    Map<Port,EList<Message>>portsMap = new HashMap<>();
	    ArrayList<Port> ports = new ArrayList<>();
        for (Port p : ThingMLHelpers.allPorts(t))
        {
            portsMap.put(p,p.getReceives());
            ports.add(p);
            ++i;
        }

    	String thing_name = t.getName();
		System.out.println(thing_name);
		CompositeState behaviour = t.getBehaviour();

		State acmInit = ThingMLFactory.eINSTANCE.createState();
		acmInit.setName("Init");
		State acmWait1 = ThingMLFactory.eINSTANCE.createState();
		acmWait1.setName("Wait1");
		State acmWait2 = ThingMLFactory.eINSTANCE.createState();
        acmWait1.setName("Wait2");

		Transition t1 =ThingMLFactory.eINSTANCE.createTransition();
		t1.setName("Wait1");
		t1.setTarget(acmWait1);
		ReceiveMessage e1 = ThingMLFactory.eINSTANCE.createReceiveMessage();
		e1.setPort(ports.get(0));
		e1.setMessage(portsMap.get(ports.get(0)).get(0));
		t1.setEvent(e1);

        Transition t2 =ThingMLFactory.eINSTANCE.createTransition();
        t2.setTarget(acmWait2);
        t2.setName("Wait2");
        ReceiveMessage e2 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e2.setPort(ports.get(1));
        e2.setMessage(portsMap.get(ports.get(1)).get(0));
        t2.setEvent(e2);

        acmInit.getOutgoing().add(t1);
        acmInit.getOutgoing().add(t2);

        Transition t3 =ThingMLFactory.eINSTANCE.createTransition();
        t3.setName("start");
        t3.setTarget(behaviour.getInitial());
        ReceiveMessage e3 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e3.setPort(ports.get(1));
        e3.setMessage(portsMap.get(ports.get(1)).get(0));
        t3.setEvent(e3);

        acmWait1.getOutgoing().add(t3);

        Transition t4 = ThingMLFactory.eINSTANCE.createTransition();
        t4.setName("start");
        t4.setTarget(behaviour.getInitial());
        ReceiveMessage e4 = ThingMLFactory.eINSTANCE.createReceiveMessage();
        e4.setPort(ports.get(0));
        e4.setMessage(portsMap.get(ports.get(0)).get(0));
        t4.setEvent(e4);

        acmWait2.getOutgoing().add(t4);

        behaviour.getSubstate().add(acmInit);
        behaviour.getSubstate().add(acmWait2);
        behaviour.getSubstate().add(acmWait1);
        behaviour.setInitial(acmInit);
	}*/

    //FIXME: this has nothing to do here. load/save is currently in compiler framework, not accessible from here. This should be part of the thingml project, together with metamodel, etc
    private void save(ThingMLModel model, String location) throws IOException {
        ThingMLStandaloneSetup.doSetup();
        if (!model.getImports().isEmpty())
            throw new Error("Only models without imports can be saved with this method. Use the 'flattenModel' method first.");

        ResourceSet rs = new ResourceSetImpl();
        Resource res = rs.createResource(URI.createFileURI(location));

        res.getContents().add(model);
        EcoreUtil.resolveAll(res);

        SaveOptions opt = SaveOptions.newBuilder().format().noValidation().getOptions();
        res.save(opt.toOptionsMap());
    }
}